"""
Human Voice Dataset Generator for Disease Detection Project
===========================================================
Generates REAL HUMAN SPEECH using Google TTS as the base voice,
then applies disease-specific acoustic processing to simulate:

- Respiratory Disease : labored breathing, reduced energy, wheezing
- Alzheimer's Disease : long pauses, slowed speech, hesitations
- ALS                 : dysarthric effects, irregular amplitude, hoarse quality
- Depression          : monotone flat pitch, very slow rate, low energy

Each disease: 25 healthy (control) + 25 disease-affected samples = 50 total
Duration: 30-60 seconds per sample
Format: WAV, 22050 Hz, mono

Controls (HC) share the same base speech but are clean/unmodified.
"""

import numpy as np
import soundfile as sf
from scipy import signal
from scipy.ndimage import uniform_filter1d
from gtts import gTTS
import os, io, random, time, tempfile
import subprocess

random.seed(42)
np.random.seed(42)

SR = 22050
OUT_DIR = "/mnt/bulk/workspace/u_384885fa8c054c8d83d6c7e591493801/c_f9b9abcb94ab43689ef1d57b9eb94d78/voicepath_ai/backend/data"

# ─── Sentence pools ──────────────────────────────────────────────────────────
# Varied English sentences that a person might naturally say during a clinical
# voice recording or conversation. Long enough to fill 30-60 seconds when
# spoken at a natural pace.

SENTENCES_RESPIRATORY = [
    "I have been feeling short of breath lately, especially when I walk up the stairs. It is getting harder to breathe at night and I often wake up coughing.",
    "The doctor told me my lungs are not working as well as they should. I have to use an inhaler twice a day now, and sometimes I still feel tight in my chest.",
    "Breathing has become a challenge for me. Even simple activities like carrying groceries make me feel winded. I need to stop and rest more often than before.",
    "I noticed that my cough started about three months ago. At first I thought it was just a cold, but it has not gone away. I sometimes hear a whistling sound when I breathe.",
    "My chest feels heavy most mornings. The doctor called it chronic bronchitis. I have to be careful in cold weather because the cold air makes my breathing much worse.",
    "I was diagnosed with asthma when I was young but it has gotten worse as I have grown older. I carry a rescue inhaler with me at all times because I never know when an attack might happen.",
    "There are days when I feel like I cannot get enough air into my lungs no matter how hard I breathe. My oxygen levels drop sometimes and I have to sit down and rest.",
    "The pollution in the city has really affected my breathing over the years. I can feel the difference on bad air quality days. My throat feels irritated and I cough more than usual.",
    "I have been on oxygen therapy for the past few months. It helps me feel less exhausted during the day. Without it I get very dizzy and cannot concentrate on anything.",
    "My respiratory specialist says I have reduced lung capacity. I used to be active and enjoyed walking in the park but now even that tires me out. I do breathing exercises every morning.",
    "Waking up at night struggling to breathe is frightening. I have to prop myself up with several pillows just to feel comfortable enough to sleep. My family is very worried about me.",
    "The spirometry test showed that my lungs are only functioning at about sixty percent capacity. The doctors want to try a new treatment and I am hopeful that it will help improve things.",
    "I notice that when I speak for a long time I start to run out of breath. This makes it hard to have long conversations. I have to take breaks when I am talking.",
    "My breathing sounds rough and scratchy even to me. People sometimes ask if I am okay because I sound like I am struggling. It is embarrassing but there is not much I can do.",
    "The cold weather and the dry air in winter are the worst for my condition. I wear a scarf over my mouth when I go outside to warm the air before it enters my lungs.",
    "I have been dealing with this condition for about five years now. It started after I got a really bad chest infection and my lungs never fully recovered from that.",
    "My doctor prescribed a steroid inhaler and a bronchodilator. I use the bronchodilator before any physical activity. It has made a small difference but I still have bad days.",
    "I used to smoke when I was younger and I think that contributed to my current breathing problems. I quit smoking ten years ago but the damage was already done.",
    "Some days are better than others. On good days I can go for a short walk and feel relatively normal. On bad days I can barely get up from the sofa without feeling breathless.",
    "I have a pulse oximeter at home that I use to monitor my oxygen saturation. If it drops below ninety-two percent I know I need to use my inhaler right away.",
    "My breathing therapist taught me pursed lip breathing and diaphragmatic breathing exercises. Practicing these every day has helped me manage my symptoms a little better.",
    "The humidity in the summer actually helps my breathing compared to the dry winter air. I use a humidifier in my bedroom at night which seems to reduce my nighttime coughing.",
    "I am on a waiting list for a pulmonary rehabilitation program. My doctor says it will help me learn how to manage my condition better and improve my quality of life.",
    "Talking about my breathing problems makes me anxious sometimes because just thinking about it makes me more aware of my breathing. It becomes a cycle that is hard to break.",
    "I have adjusted my lifestyle significantly since my diagnosis. I no longer do high-intensity exercise and I avoid environments with smoke or strong chemical smells.",
]

SENTENCES_ALZHEIMERS = [
    "I wanted to tell you about my morning but I... I seem to have... let me think now... I was going to say something about breakfast I believe. Yes, I had... I had eggs I think.",
    "My daughter came to visit me yesterday, or was it the day before? Time gets a bit confusing for me these days. She is... she is a lovely girl. I always remember her smile.",
    "I used to know everyone's phone number by heart but now I have to look everything up. My memory is not what it used to be. I forget simple things like where I put my glasses.",
    "The doctor gave me some new medication last week. Or was it last month? I have to write things down now because otherwise... I forget. I keep a notebook by my bed for that.",
    "I remember growing up we used to... we would... there was a place we would go on Sundays. I can picture it clearly but the name... the name escapes me right now.",
    "Sometimes I start a sentence and I forget what I was going to say halfway through. It is very frustrating. I know what I want to express but the words do not always come.",
    "My wife... my wife always reminds me to take my pills in the morning. Without her I would probably forget. She writes everything down for me which is very kind of her.",
    "I have been living in this house for... for many years. I know every corner of it. But sometimes I wake up at night and for a moment I am not sure where I am. It passes.",
    "Reading used to be my favourite pastime. I would read a book a week. Now I have to read the same paragraph several times before it... before it stays with me.",
    "I went to the shops yesterday and I... I had a list but I lost the list. I stood in the middle of the shop trying to remember what I needed. I came home with the wrong things.",
    "My grandchildren are growing up so fast. I sometimes get confused between them... between their names. I know their faces perfectly but calling the right name takes a moment.",
    "I was a teacher for thirty years. I remember my students very clearly, the ones from the early years especially. But what I did last Tuesday is... harder to recall.",
    "There are days when everything is quite clear and I feel like my old self. Other days things feel... foggy. Like trying to see through a frosted window. I prefer the clear days.",
    "I know I repeat myself sometimes. My family gently reminds me when I tell the same story twice. I try not to feel embarrassed about it but it is not always easy.",
    "The calendar on the wall helps me keep track of things. My son put it up for me. Every morning I look at it first thing so I know what day it is and what I have planned.",
    "I was going to tell you something important... let me think... it was about... I had it just a moment ago. I am sorry, I think I have lost that thought. Perhaps it will come back.",
    "My caregiver helps me with meals and appointments. She is very patient with me when I ask the same question more than once. I appreciate her kindness more than I can say.",
    "I still enjoy music very much. Old songs from my youth I remember perfectly. Every word, every melody. It is interesting that those memories stay sharp even when other things fade.",
    "I get a bit confused when there are too many people talking at once. Crowded places overwhelm me now. I prefer quiet environments where I can follow one conversation at a time.",
    "My family took me to a doctor who specialises in memory problems. The tests were... there were many tests. I tried my best. Some questions were easier than others.",
    "I used to be very organised. Everything had a place. Now I find things in unusual spots. I put my keys in the refrigerator once. I laughed about it but also felt a bit worried.",
    "Looking at old photographs helps me remember. I can sit for hours looking at pictures of my family and my past. Those images bring back feelings and fragments of memories.",
    "I find comfort in routine. Having the same schedule every day helps me feel more in control. When things change unexpectedly I find it harder to cope with the confusion.",
    "My biggest fear is forgetting the faces of the people I love. Everything else I can manage losing, but not that. Not the faces of my children and grandchildren.",
    "I want people to know that even with memory difficulties I am still the same person inside. I still have feelings and opinions and I still want to be treated with dignity and respect.",
]

SENTENCES_ALS = [
    "Speaking has become difficult for me. My tongue and lips do not move the way they used to. I have to concentrate very hard on every word I say.",
    "I was diagnosed about eighteen months ago. At first I just noticed some weakness in my hands. Then it spread to my arms and eventually started affecting my speech.",
    "My voice sounds different now even to me. It has become quieter and sometimes slurred. I have been working with a speech therapist to maintain as much communication as possible.",
    "Using a communication device has helped a lot. But I still try to speak when I can because using my own voice feels important to me. I do not want to give that up.",
    "Simple things like swallowing have become challenging. I have to be careful when I eat and drink. I sometimes choke and that is frightening. I eat smaller portions now.",
    "I was a teacher and talking was my whole career. Now speaking takes so much effort. I get tired after just a few sentences. The fatigue is something people do not always understand.",
    "My family says they can still understand me most of the time which gives me hope. I try to speak slowly and clearly so my words are as easy to follow as possible.",
    "The progression of this disease varies from person to person. For me the speech problems came relatively early. Some people with my condition keep their speech longer than I have.",
    "I have learned to communicate in other ways when speaking is too hard. I use text messages and apps on my phone. Technology has been a real gift for people in my situation.",
    "There are days when I can speak more easily and days when even a single sentence exhausts me. I try to save my voice for the conversations that matter most to me.",
    "My breathing muscles have also been affected. I sometimes need to pause mid sentence not because I forgot what I was saying but because I need to catch my breath.",
    "I still have so much I want to say to my family and friends. Every conversation feels precious to me now in a way that it never did before my diagnosis.",
    "The hardest part emotionally is feeling trapped inside. My mind is completely clear and sharp but my body is not cooperating. That disconnect is the most difficult thing to accept.",
    "I have recorded videos of myself talking so my family will have my voice to remember after I am gone. Making those recordings was one of the most emotional things I have ever done.",
    "I attend a support group for people with motor neurone disease. Hearing other people share their experiences helps me feel less alone. We understand each other in a unique way.",
    "My speech therapist has been incredible. She taught me techniques to conserve my voice and to make each word as clear as possible. I am grateful for her expertise and patience.",
    "When my speech is unclear I sometimes spell out words by pointing to letters on a board. It is slow but it works. Communication is too important to give up on.",
    "People sometimes speak to me as if my intellect has been affected along with my speech. I have to remind myself that they mean well even when it is frustrating.",
    "I try to stay positive but I am realistic about what is ahead. I want to make the most of every day and every conversation while I still have the ability to speak.",
    "My family has adapted remarkably well to my changing communication needs. They have become excellent at understanding me even when my speech is not clear.",
    "One thing I have learned through this experience is the incredible value of human communication. We take our voices for granted until the moment they start to slip away.",
    "I still have my sense of humour and my personality even as my voice changes. The people who know me can still see me in my words even when those words are harder to produce.",
    "Research into this disease is progressing. I try to stay informed about new treatments and I participate in research studies when I can. I want to help future patients.",
    "My goal every day is to communicate as effectively as I can for as long as I can. I refuse to stop trying. Each word I speak is a small victory against this disease.",
    "For anyone else going through this I want to say do not give up on communication. There are tools and people who can help. Your voice and your words still matter.",
]

SENTENCES_DEPRESSION = [
    "I do not know how to explain how I feel. It is like there is a weight on me all the time. Getting out of bed in the morning takes more effort than I can sometimes manage.",
    "I used to enjoy so many things. Cooking, seeing friends, going for walks. Now nothing really brings me pleasure. I go through the motions but I do not feel anything.",
    "I sleep too much but I am always tired. Even after ten hours of sleep I wake up exhausted. My body feels heavy and everything requires more energy than I have.",
    "Concentrating is very hard. I sit down to read or work and my mind just drifts. I forget what I was doing. Simple tasks take me much longer than they should.",
    "I do not talk to people much anymore. I cancel plans because I cannot face being around others. I know I am isolating myself but I cannot seem to change it.",
    "There are days when I feel completely empty. Not sad exactly, just hollow. Like the part of me that used to care about things is switched off and I cannot find the switch.",
    "My appetite has changed. Some weeks I barely eat and other weeks I eat too much. I have lost interest in food even things that used to be my favourite meals.",
    "I have been feeling this way for about eight months. Some days are a little better than others but there is no real good day anymore. Everything feels grey.",
    "I know that what I am experiencing has a name and that it is an illness. That understanding helps me be a bit kinder to myself on the hard days.",
    "My therapist says I need to try to maintain a routine. I try. Some days I manage it and some days I cannot get beyond sitting on the sofa and staring at the wall.",
    "The feeling that things will never get better is the worst part. Rationally I know that is not true but emotionally it feels completely real and overwhelming.",
    "I have lost interest in my appearance. I used to take pride in how I looked. Now getting dressed feels pointless. I wear the same things day after day.",
    "Small things that never used to bother me now feel insurmountable. A phone call I need to make, a form I need to fill in. These things loom over me for days.",
    "I miss who I used to be. I was energetic and optimistic and I made plans for the future. That version of me feels very far away right now.",
    "My family is worried about me and I feel guilty about that. I do not want to be a burden but I also do not have the energy to pretend that everything is fine.",
    "I have good moments sometimes. A joke on television that makes me genuinely laugh, or a conversation that I actually engage with. I hold onto those moments.",
    "The medication I was prescribed takes time to work. I know that. But when you are in the middle of it waiting feels almost impossible.",
    "Exercise is supposed to help and when I force myself to go for a walk I do feel slightly better afterwards. The hard part is finding the motivation to start.",
    "I feel disconnected from other people. Like there is a glass wall between me and everyone else. I can see them but I cannot quite reach them or let them reach me.",
    "Some days I am angry at myself for not being able to just feel better. I know depression is not a choice but the stigma we carry makes it hard not to blame yourself.",
    "I am trying very hard to get better. I go to therapy, I take my medication, I try to follow all the advice. I hope that eventually it will start to make a real difference.",
    "The mornings are the hardest. I wake up and within seconds the heaviness is back. I have learned to give myself a few minutes before expecting anything from the day.",
    "I remind myself that this is temporary even when it does not feel that way. Other people have come through this and found their way back. I want to believe I will too.",
    "Talking about how I feel is actually helpful even when it is hard. Keeping it all inside made everything worse. I am learning that asking for help is not weakness.",
    "I still have things I want to do and people I love. That keeps me going on the days when everything else feels pointless. I hold onto those reasons to keep trying.",
]

# Healthy control sentences (same neutral content for all 4 disease controls)
SENTENCES_HEALTHY = [
    "Good morning. Today I would like to talk about my daily routine. I wake up at seven o'clock and have a healthy breakfast before starting my day.",
    "I enjoy spending time with my family on weekends. We often go for walks in the park or visit local museums. It is a wonderful way to stay connected.",
    "My hobbies include reading books, gardening, and cooking. I find these activities relaxing and they help me unwind after a busy day at work.",
    "I have been feeling quite well lately. My energy levels are good and I have been sleeping well. I try to maintain a healthy diet and exercise regularly.",
    "The weather has been beautiful this week. I took advantage of it to go for a long walk by the river. The fresh air was very refreshing.",
    "I completed a project at work last week that I had been working on for several months. I felt very satisfied when it was finally finished.",
    "My children are doing well in school. The eldest has developed a real interest in science and the younger one loves drawing and art.",
    "I visited my parents last weekend. We had a lovely meal together and talked for hours. It reminded me how important family connections are.",
    "I have recently started taking a cooking class. I am learning to make dishes from different countries. It is a fun way to learn about other cultures.",
    "Keeping a healthy balance between work and personal life is something I think about a lot. I try to switch off from work emails after six in the evening.",
    "I meditate for fifteen minutes every morning. It helps me feel calm and focused for the rest of the day. I recommend it to anyone who feels stressed.",
    "I read an interesting article about astronomy last week. The vastness of the universe is something I find both humbling and inspiring to think about.",
    "My physical checkup went well. The doctor said my blood pressure, cholesterol, and everything else is within normal ranges. I was very pleased.",
    "I have been learning to play the guitar for the past few months. Progress is slow but I can already play a few simple songs which gives me a lot of satisfaction.",
    "Volunteering at the local community centre has been very rewarding. Meeting people from different walks of life has broadened my perspective considerably.",
    "I try to walk at least ten thousand steps every day. It keeps me active and I find that I think more clearly after a good walk in the fresh air.",
    "I recently rediscovered my love of painting. I set up a small studio space in a spare room and I spend Sunday afternoons working on landscapes.",
    "Staying hydrated and getting enough sleep are two things I focus on for my health. Simple habits but they make a significant difference to how I feel.",
    "I had a wonderful conversation with an old friend from university who I had not spoken to in years. It was as if no time had passed at all.",
    "Planning a holiday is something I really enjoy. I spent the evening looking at different destinations and imagining all the things I might see and do.",
    "My neighbourhood has a friendly atmosphere. People say hello to each other and there is a real sense of community here which I value greatly.",
    "I completed my first five kilometre run last Saturday. I had been training for three months and finishing it was a real achievement I am proud of.",
    "Listening to music is one of my greatest pleasures. I have a varied taste and I enjoy everything from classical compositions to modern jazz.",
    "I have been keeping a daily journal for the past year. Writing about my thoughts and experiences has been surprisingly therapeutic and insightful.",
    "Life feels balanced and purposeful right now. I have good health, meaningful work, loving relationships, and things I look forward to every day.",
]


def tts_to_wav(text, speed_factor=1.0):
    """Generate human speech WAV from text using gTTS, return numpy array."""
    # Write to temp mp3
    with tempfile.NamedTemporaryFile(suffix='.mp3', delete=False) as tmp_mp3:
        mp3_path = tmp_mp3.name
    with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp_wav:
        wav_path = tmp_wav.name

    try:
        tts = gTTS(text=text, lang='en', slow=False)
        tts.save(mp3_path)
        # Convert mp3 → wav using ffmpeg
        cmd = ['ffmpeg', '-y', '-i', mp3_path, '-ar', str(SR), '-ac', '1',
               '-acodec', 'pcm_f32le', wav_path]
        subprocess.run(cmd, check=True, capture_output=True)
        y, _ = sf.read(wav_path)
        y = y.astype(np.float32)
    finally:
        os.unlink(mp3_path)
        os.unlink(wav_path)

    # Apply speed change via resampling
    if speed_factor != 1.0:
        new_len = int(len(y) / speed_factor)
        y = signal.resample(y, new_len)

    return y


def normalize(y, target_db=-3.0):
    peak = np.max(np.abs(y))
    if peak < 1e-9:
        return y
    target_peak = 10 ** (target_db / 20)
    return y * (target_peak / peak)


def add_silence(y, sr, pre_sec=0.5, post_sec=0.5):
    pre = np.zeros(int(pre_sec * sr))
    post = np.zeros(int(post_sec * sr))
    return np.concatenate([pre, y, post])


def insert_pauses(y, sr, n_pauses=3, pause_duration_range=(0.5, 2.5)):
    """Insert silence gaps at random positions — simulates word-finding pauses."""
    indices = sorted(random.sample(range(int(sr), len(y) - int(sr)), min(n_pauses, len(y) // sr)))
    parts = []
    prev = 0
    for idx in indices:
        parts.append(y[prev:idx])
        pause_len = int(random.uniform(*pause_duration_range) * sr)
        parts.append(np.zeros(pause_len, dtype=np.float32))
        prev = idx
    parts.append(y[prev:])
    return np.concatenate(parts)


def add_tremor(y, sr, rate=5.0, depth=0.15):
    """Add vocal tremor — amplitude modulation at tremor frequency (Parkinson-like)."""
    t = np.arange(len(y)) / sr
    modulation = 1.0 + depth * np.sin(2 * np.pi * rate * t)
    return y * modulation


def add_breathing_noise(y, sr, level=0.04):
    """Add continuous breath noise under speech (respiratory)."""
    from scipy.signal import butter, lfilter
    noise = np.random.randn(len(y)).astype(np.float32)
    b, a = butter(2, [100 / (sr / 2), 800 / (sr / 2)], btype='band')
    breath = lfilter(b, a, noise) * level
    return y + breath


def add_wheeze(y, sr, freq=700, level=0.06):
    """Overlay a wheeze tone (respiratory disease)."""
    t = np.arange(len(y)) / sr
    wheeze = np.sin(2 * np.pi * freq * t)
    # Modulate wheeze amplitude with breathing rhythm (~0.3 Hz)
    envelope = 0.5 + 0.5 * np.sin(2 * np.pi * 0.3 * t)
    return y + wheeze * envelope * level


def reduce_energy_dips(y, sr, dip_prob=0.2, dip_depth=0.4):
    """Randomly reduce energy in short bursts — reduced breath support."""
    frame = int(0.2 * sr)
    out = y.copy()
    n_frames = len(y) // frame
    for i in range(n_frames):
        if random.random() < dip_prob:
            s, e = i * frame, (i + 1) * frame
            out[s:e] *= (1.0 - dip_depth)
    return out


def flatten_pitch_prosody(y, sr, flatten_degree=0.6):
    """
    Flatten dynamic range to simulate monotone speech (depression).
    Compresses amplitude variation → less prosodic range.
    """
    frame = int(0.05 * sr)
    out = y.copy()
    n = len(y) // frame
    rms_vals = [np.sqrt(np.mean(y[i*frame:(i+1)*frame]**2) + 1e-12) for i in range(n)]
    mean_rms = np.mean(rms_vals)
    for i in range(n):
        s, e = i * frame, (i + 1) * frame
        r = rms_vals[i]
        # Pull amplitude towards mean (flatten prosody)
        correction = (mean_rms / (r + 1e-9)) ** flatten_degree
        correction = np.clip(correction, 0.3, 3.0)
        out[s:e] = out[s:e] * correction
    return out


def add_dysarthria(y, sr, irregularity=0.35, nasal_boost=0.25):
    """
    Simulate dysarthric speech (ALS): irregular amplitude + nasal formant boost.
    """
    from scipy.signal import butter, lfilter
    # Irregular amplitude modulation
    n = len(y)
    mod_frame = int(0.03 * sr)
    modulation = np.ones(n, dtype=np.float32)
    for i in range(0, n, mod_frame):
        val = 1.0 + irregularity * (random.random() - 0.5)
        modulation[i:i+mod_frame] = val
    modulation = uniform_filter1d(modulation, size=int(sr * 0.02))
    dysarthric = y * modulation

    # Boost nasal resonance (200-500 Hz)
    b, a = butter(2, [200 / (sr / 2), 500 / (sr / 2)], btype='band')
    nasal = lfilter(b, a, y)
    dysarthric = dysarthric + nasal_boost * nasal

    # Add slight hoarseness (high-freq noise)
    hoarse = np.random.randn(n).astype(np.float32) * 0.012
    return dysarthric + hoarse


def ensure_duration(y, sr, min_sec=30, max_sec=60):
    """Pad or trim to fit the target duration range."""
    target = random.randint(int(min_sec * sr), int(max_sec * sr))
    if len(y) >= target:
        return y[:target]
    # Loop/tile to fill
    reps = (target // len(y)) + 1
    y_long = np.tile(y, reps)
    return y_long[:target]


# ─── Disease generators ───────────────────────────────────────────────────────

def make_respiratory_disease(text, idx):
    print(f"    [RESP-D {idx}] generating...", end=' ', flush=True)
    y = tts_to_wav(text, speed_factor=random.uniform(0.85, 1.0))
    y = add_breathing_noise(y, SR, level=random.uniform(0.05, 0.10))
    freq = random.uniform(500, 900)
    y = add_wheeze(y, SR, freq=freq, level=random.uniform(0.05, 0.09))
    y = reduce_energy_dips(y, SR, dip_prob=random.uniform(0.15, 0.30), dip_depth=random.uniform(0.3, 0.55))
    y = ensure_duration(y, SR)
    print(f"{len(y)/SR:.1f}s")
    return normalize(y)


def make_alzheimers_disease(text, idx):
    print(f"    [ALZ-D  {idx}] generating...", end=' ', flush=True)
    y = tts_to_wav(text, speed_factor=random.uniform(0.65, 0.80))
    y = insert_pauses(y, SR, n_pauses=random.randint(4, 8),
                      pause_duration_range=(0.8, 3.0))
    # Occasional repetition of a short segment
    if random.random() < 0.4 and len(y) > SR * 5:
        seg_start = random.randint(SR, len(y) - SR * 3)
        rep_len = random.randint(int(SR * 0.5), int(SR * 2))
        segment = y[seg_start:seg_start + rep_len]
        pause = np.zeros(int(SR * 0.3), dtype=np.float32)
        y = np.concatenate([y[:seg_start + rep_len], pause, segment, y[seg_start + rep_len:]])
    y = ensure_duration(y, SR)
    print(f"{len(y)/SR:.1f}s")
    return normalize(y)


def make_als_disease(text, idx):
    print(f"    [ALS-D  {idx}] generating...", end=' ', flush=True)
    y = tts_to_wav(text, speed_factor=random.uniform(0.70, 0.90))
    y = add_dysarthria(y, SR, irregularity=random.uniform(0.25, 0.5),
                       nasal_boost=random.uniform(0.2, 0.35))
    y = insert_pauses(y, SR, n_pauses=random.randint(2, 5),
                      pause_duration_range=(0.4, 1.8))
    y = ensure_duration(y, SR)
    print(f"{len(y)/SR:.1f}s")
    return normalize(y)


def make_depression_disease(text, idx):
    print(f"    [DEP-D  {idx}] generating...", end=' ', flush=True)
    y = tts_to_wav(text, speed_factor=random.uniform(0.72, 0.85))
    y = flatten_pitch_prosody(y, SR, flatten_degree=random.uniform(0.5, 0.75))
    # Low energy: reduce overall volume
    y = y * random.uniform(0.35, 0.55)
    y = insert_pauses(y, SR, n_pauses=random.randint(2, 5),
                      pause_duration_range=(0.5, 2.0))
    y = ensure_duration(y, SR)
    print(f"{len(y)/SR:.1f}s")
    return normalize(y, target_db=-8.0)


def make_healthy(text, idx, tag='HC'):
    print(f"    [{tag}-HC {idx}] generating...", end=' ', flush=True)
    y = tts_to_wav(text, speed_factor=random.uniform(0.95, 1.10))
    y = add_silence(y, SR, pre_sec=random.uniform(0.2, 0.5), post_sec=random.uniform(0.2, 0.5))
    y = ensure_duration(y, SR)
    print(f"{len(y)/SR:.1f}s")
    return normalize(y)


# ─── Main ─────────────────────────────────────────────────────────────────────

DISEASES = {
    'respiratory': {
        'sentences_disease': SENTENCES_RESPIRATORY,
        'sentences_healthy': SENTENCES_HEALTHY,
        'fn_disease': make_respiratory_disease,
        'fn_healthy': make_healthy,
    },
    'alzheimers': {
        'sentences_disease': SENTENCES_ALZHEIMERS,
        'sentences_healthy': SENTENCES_HEALTHY,
        'fn_disease': make_alzheimers_disease,
        'fn_healthy': make_healthy,
    },
    'als': {
        'sentences_disease': SENTENCES_ALS,
        'sentences_healthy': SENTENCES_HEALTHY,
        'fn_disease': make_als_disease,
        'fn_healthy': make_healthy,
    },
    'depression': {
        'sentences_disease': SENTENCES_DEPRESSION,
        'sentences_healthy': SENTENCES_HEALTHY,
        'fn_disease': make_depression_disease,
        'fn_healthy': make_healthy,
    },
}

def main():
    total = 0
    for disease_key, cfg in DISEASES.items():
        out_dir = os.path.join(OUT_DIR, disease_key)
        os.makedirs(out_dir, exist_ok=True)

        # Remove old synthetic files
        for f in os.listdir(out_dir):
            if f.endswith('.wav'):
                os.remove(os.path.join(out_dir, f))

        print(f"\n{'='*55}")
        print(f"  {disease_key.upper()} DATASET")
        print(f"  Generating 25 disease + 25 healthy = 50 samples")
        print(f"{'='*55}")

        sentences_d = cfg['sentences_disease']
        sentences_h = cfg['sentences_healthy']

        # 25 disease samples
        print(f"\n  Disease samples (25):")
        for i in range(1, 26):
            text = sentences_d[(i - 1) % len(sentences_d)]
            try:
                y = cfg['fn_disease'](text, i)
                fname = f"{disease_key}_disease_{i:03d}.wav"
                sf.write(os.path.join(out_dir, fname), y, SR)
                total += 1
            except Exception as e:
                print(f"    ERROR sample {i}: {e}")

        # 25 healthy control samples
        print(f"\n  Healthy control samples (25):")
        for i in range(1, 26):
            text = sentences_h[(i - 1) % len(sentences_h)]
            try:
                y = cfg['fn_healthy'](text, i, tag=disease_key[:4].upper())
                fname = f"{disease_key}_healthy_{i:03d}.wav"
                sf.write(os.path.join(out_dir, fname), y, SR)
                total += 1
            except Exception as e:
                print(f"    ERROR sample {i}: {e}")

        files = [f for f in os.listdir(out_dir) if f.endswith('.wav')]
        print(f"\n  Done: {len(files)} files in {out_dir}/")

    print(f"\n{'='*55}")
    print(f"  COMPLETE: {total} human voice WAV files generated")
    print(f"{'='*55}\n")


if __name__ == '__main__':
    main()
