"""
Synthetic audio dataset generator for disease detection via voice/audio analysis.
Generates 50 samples per disease (30-60 seconds each) with disease-specific acoustic features.

Diseases: Respiratory, Alzheimer's, Depression, ALS
NOTE: These are SYNTHETIC samples — not real patient recordings.
      Suitable for ML pipeline development and testing.
"""

import numpy as np
import soundfile as sf
import os
import random

SAMPLE_RATE = 22050
OUTPUT_DIR = "disease_audio_dataset"
SAMPLES_PER_CLASS = 50

# Acoustic characteristic parameters per disease
DISEASE_CONFIGS = {
    "Respiratory_Disease": {
        "description": "Wheezing, irregular breathing, cough bursts, reduced breath support",
        "base_freq_range": (80, 200),
        "wheeze_freq_range": (400, 1200),
        "breath_noise_level": 0.35,
        "cough_probability": 0.6,
        "wheeze_probability": 0.75,
        "speech_energy": 0.5,
        "pause_frequency": 0.3,
        "duration_range": (30, 60),
    },
    "Alzheimers_Disease": {
        "description": "Long pauses, word repetitions, hesitations, slower speech rate, pitch variability",
        "base_freq_range": (120, 220),
        "wheeze_freq_range": (200, 400),
        "breath_noise_level": 0.05,
        "cough_probability": 0.05,
        "wheeze_probability": 0.05,
        "speech_energy": 0.45,
        "pause_frequency": 0.65,   # high — characteristic long pauses
        "pitch_wander": 0.3,
        "duration_range": (40, 60),
    },
    "Depression": {
        "description": "Monotone flat pitch, slow speech rate, low energy, reduced prosody",
        "base_freq_range": (90, 160),
        "wheeze_freq_range": (200, 350),
        "breath_noise_level": 0.08,
        "cough_probability": 0.05,
        "wheeze_probability": 0.05,
        "speech_energy": 0.3,      # low energy
        "pause_frequency": 0.4,
        "pitch_variation": 0.05,   # very flat pitch
        "duration_range": (35, 60),
    },
    "ALS": {
        "description": "Dysarthric speech, irregular amplitude, reduced articulation precision, nasal quality",
        "base_freq_range": (100, 200),
        "wheeze_freq_range": (300, 600),
        "breath_noise_level": 0.15,
        "cough_probability": 0.2,
        "wheeze_probability": 0.3,
        "speech_energy": 0.55,
        "pause_frequency": 0.45,
        "amplitude_irregularity": 0.5,  # characteristic of ALS dysarthria
        "duration_range": (30, 60),
    },
}


def pink_noise(n):
    """Generate pink noise (1/f) approximation."""
    white = np.random.randn(n)
    # Simple pink noise via FIR filter approximation
    b = np.array([0.049922035, -0.095993537, 0.050612699, -0.004408786])
    a = np.array([1, -2.494956002, 2.017265875, -0.522189400])
    from scipy.signal import lfilter
    return lfilter(b, a, white)


def voiced_segment(duration_sec, f0, sr, jitter=0.02, shimmer=0.05, noise_level=0.1):
    """Generate a voiced (speech-like) segment with glottal pulse model."""
    n = int(duration_sec * sr)
    t = np.linspace(0, duration_sec, n)

    # Fundamental frequency with slight jitter
    f0_jitter = f0 * (1 + jitter * np.random.randn(n))
    phase = np.cumsum(2 * np.pi * f0_jitter / sr)

    # Glottal pulse approximation (sum of harmonics with roll-off)
    signal = np.zeros(n)
    for k in range(1, 12):
        amplitude = (1 / k) * (1 + shimmer * np.random.randn())
        signal += amplitude * np.sin(k * phase)

    # Add breathiness noise
    signal += noise_level * np.random.randn(n)

    # Smooth amplitude envelope (speech rhythm ~4-8 syllables/sec)
    syllable_rate = random.uniform(3, 6)
    envelope = 0.5 + 0.5 * np.sin(2 * np.pi * syllable_rate * t + random.uniform(0, 2*np.pi))
    signal *= envelope

    return signal / (np.max(np.abs(signal)) + 1e-9)


def silence_segment(duration_sec, sr, noise_floor=0.005):
    """Generate near-silence (breath pause) segment."""
    n = int(duration_sec * sr)
    return noise_floor * np.random.randn(n)


def cough_burst(sr, duration=0.4):
    """Simulate a cough burst."""
    n = int(duration * sr)
    t = np.linspace(0, duration, n)
    burst = np.random.randn(n)
    # Cough envelope: sharp attack, quick decay
    envelope = np.exp(-t * 12) * (1 - np.exp(-t * 80))
    burst *= envelope * 2
    # Add high-frequency character
    from scipy.signal import butter, lfilter
    b, a = butter(4, [500/(sr/2), 4000/(sr/2)], btype='band')
    return lfilter(b, a, burst)


def wheeze_segment(duration_sec, sr, freq=800):
    """Simulate wheeze — high-pitched continuous tone with modulation."""
    n = int(duration_sec * sr)
    t = np.linspace(0, duration_sec, n)
    # Wheeze: narrow-band tone with amplitude modulation
    carrier = np.sin(2 * np.pi * freq * t)
    modulator = 0.5 + 0.5 * np.sin(2 * np.pi * 8 * t)  # 8 Hz AM
    wheeze = carrier * modulator * 0.3
    return wheeze


def generate_respiratory_sample(config, sr, duration):
    """Respiratory disease: wheezing, coughing, labored breathing."""
    segments = []
    time_built = 0.0

    while time_built < duration:
        seg_type = random.random()

        if seg_type < config["cough_probability"] * 0.15:
            seg = cough_burst(sr)
        elif seg_type < config["wheeze_probability"] * 0.3:
            wlen = random.uniform(0.5, 2.5)
            wfreq = random.uniform(*config["wheeze_freq_range"])
            seg = wheeze_segment(wlen, sr, wfreq)
        elif seg_type < config["pause_frequency"] * 0.5:
            seg = silence_segment(random.uniform(0.3, 1.5), sr)
        else:
            f0 = random.uniform(*config["base_freq_range"])
            slen = random.uniform(0.5, 2.0)
            seg = voiced_segment(slen, f0, sr, noise_level=config["breath_noise_level"])

        segments.append(seg)
        time_built += len(seg) / sr

    audio = np.concatenate(segments)[:int(duration * sr)]
    return audio * config["speech_energy"]


def generate_alzheimers_sample(config, sr, duration):
    """Alzheimer's: long pauses, hesitation, slow wandering pitch."""
    segments = []
    time_built = 0.0

    while time_built < duration:
        if random.random() < config["pause_frequency"]:
            # Characteristic long pauses
            pause_len = random.uniform(0.8, 3.5)
            seg = silence_segment(pause_len, sr)
        else:
            f0 = random.uniform(*config["base_freq_range"])
            # Wandering pitch (word-finding difficulty)
            f0 += config.get("pitch_wander", 0.1) * 50 * np.random.randn()
            f0 = np.clip(f0, 80, 300)
            slen = random.uniform(0.3, 1.2)
            seg = voiced_segment(slen, f0, sr, jitter=0.04, noise_level=0.08)
            # Repetition: occasionally duplicate segment
            if random.random() < 0.2:
                segments.append(seg)
                time_built += len(seg) / sr

        segments.append(seg)
        time_built += len(seg) / sr

    audio = np.concatenate(segments)[:int(duration * sr)]
    return audio * config["speech_energy"]


def generate_depression_sample(config, sr, duration):
    """Depression: monotone flat pitch, low energy, slow rate."""
    segments = []
    time_built = 0.0

    while time_built < duration:
        if random.random() < config["pause_frequency"]:
            seg = silence_segment(random.uniform(0.4, 2.0), sr)
        else:
            # Very flat pitch — minimal variation
            base_f0 = random.uniform(*config["base_freq_range"])
            variation = config.get("pitch_variation", 0.05)
            f0 = base_f0 + variation * 20 * np.random.randn()
            f0 = np.clip(f0, 80, 250)
            slen = random.uniform(0.6, 2.5)  # slower speech
            seg = voiced_segment(slen, f0, sr, jitter=0.01, shimmer=0.02, noise_level=0.04)

        segments.append(seg)
        time_built += len(seg) / sr

    audio = np.concatenate(segments)[:int(duration * sr)]
    return audio * config["speech_energy"]


def generate_als_sample(config, sr, duration):
    """ALS: dysarthric — irregular amplitude, reduced precision, nasal quality."""
    segments = []
    time_built = 0.0

    while time_built < duration:
        if random.random() < config["cough_probability"] * 0.2:
            seg = cough_burst(sr, duration=0.3)
        elif random.random() < config["pause_frequency"]:
            seg = silence_segment(random.uniform(0.3, 1.8), sr)
        else:
            f0 = random.uniform(*config["base_freq_range"])
            slen = random.uniform(0.4, 1.5)
            seg = voiced_segment(slen, f0, sr, jitter=0.06, shimmer=0.1, noise_level=0.12)

            # Amplitude irregularity (dysarthria)
            irreg = config.get("amplitude_irregularity", 0.3)
            n = len(seg)
            modulation = 1 + irreg * np.random.randn(n) * 0.1
            # Smooth the modulation slightly
            from scipy.ndimage import uniform_filter1d
            modulation = uniform_filter1d(modulation, size=int(sr * 0.05))
            seg *= modulation

            # Nasal quality: boost 200-500 Hz
            from scipy.signal import butter, lfilter
            b, a = butter(2, [200/(sr/2), 500/(sr/2)], btype='band')
            nasal = lfilter(b, a, seg)
            seg = seg + 0.3 * nasal

        segments.append(seg)
        time_built += len(seg) / sr

    audio = np.concatenate(segments)[:int(duration * sr)]
    return audio * config["speech_energy"]


GENERATORS = {
    "Respiratory_Disease": generate_respiratory_sample,
    "Alzheimers_Disease": generate_alzheimers_sample,
    "Depression": generate_depression_sample,
    "ALS": generate_als_sample,
}


def main():
    random.seed(42)
    np.random.seed(42)

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    total_generated = 0

    for disease, config in DISEASE_CONFIGS.items():
        disease_dir = os.path.join(OUTPUT_DIR, disease)
        os.makedirs(disease_dir, exist_ok=True)
        gen_fn = GENERATORS[disease]

        print(f"\n[{disease}] Generating {SAMPLES_PER_CLASS} samples...")
        print(f"  Characteristics: {config['description']}")

        for i in range(1, SAMPLES_PER_CLASS + 1):
            duration = random.uniform(*config["duration_range"])
            audio = gen_fn(config, SAMPLE_RATE, duration)

            # Normalize to -3 dBFS
            peak = np.max(np.abs(audio))
            if peak > 0:
                audio = audio / peak * 0.707

            filename = f"{disease}_sample_{i:03d}.wav"
            filepath = os.path.join(disease_dir, filename)
            sf.write(filepath, audio.astype(np.float32), SAMPLE_RATE)

            if i % 10 == 0:
                print(f"  [{i}/{SAMPLES_PER_CLASS}] {filename} ({duration:.1f}s)")

            total_generated += 1

        print(f"  Done: {SAMPLES_PER_CLASS} files in {disease_dir}/")

    print(f"\n✓ Dataset complete: {total_generated} audio files in '{OUTPUT_DIR}/'")
    print(f"  Structure:")
    for disease in DISEASE_CONFIGS:
        print(f"    {OUTPUT_DIR}/{disease}/  ({SAMPLES_PER_CLASS} WAV files)")
    print(f"\n  Format: WAV, 22050 Hz, mono, float32")
    print(f"  Duration per sample: 30-60 seconds")


if __name__ == "__main__":
    main()
